from abstra.forms import app, file_input, select, submit, response
from scr.vision_api_project.process_document import processar_documento

@app.route("/")
def process_document():
    # Define a interface do formulário
    tipo_documento = select(
        label="Select Document Type",
        options=["CPF", "RG", "CNH"]
    )

    file = file_input(label="Upload your document", accept=["image/*"])

    submit_button = submit(label="Process Document")

    if submit_button:
        # Validação
        if not file or not tipo_documento:
            return response({"error": "Please provide both file and document type."}, status=400)

        # Processa o arquivo
        file_path = file.get("path")
        resultado = processar_documento(file_path, tipo_documento)

        # Retorna o resultado como JSON
        return response(resultado)

# Configuração do app
if __name__ == "__main__":
    app.run()
